package com.hexaware.hotpot.entities;

public class Menu {

}
