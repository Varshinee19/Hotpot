package com.hexaware.hotpot.entities;

public class Cart {

}
