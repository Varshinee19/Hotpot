package com.hexaware.hotpot.service;

import org.springframework.stereotype.Service;

import com.hexaware.hotpot.entities.Payment;
@Service
public class PaymentImpl implements IPaymentService {

	@Override
	public Payment makePayment(Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Payment getPaymentById(int paymentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateStatus(int paymentId) {
		// TODO Auto-generated method stub
		return null;
	}

}
