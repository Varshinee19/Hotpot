package com.hexaware.hotpot.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hexaware.hotpot.entities.Menu;
@Service
public class MenuImpl implements IMenuService {

	@Override
	public Menu addMenuItem(Menu menu) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Menu updateMenu(Menu menu) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Menu> getMenuByRestaurant(int resid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Menu> getMenuByCategory(int catid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Menu> getAllMenu() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteMenuItem(int menuid) {
		// TODO Auto-generated method stub
		return null;
	}

}
