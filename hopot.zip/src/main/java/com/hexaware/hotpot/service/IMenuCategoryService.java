package com.hexaware.hotpot.service;

public interface IMenuCategoryService {

}
