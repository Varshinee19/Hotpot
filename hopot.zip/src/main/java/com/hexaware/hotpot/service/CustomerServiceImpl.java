package com.hexaware.hotpot.service;

import java.util.List;

import com.hexaware.hotpot.entities.Customer;
import com.hexaware.hotpot.entities.Orders;

public class CustomerServiceImpl implements ICustomerService {

	
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Customer UpdateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	public Customer getCustomerByMail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public String deleteCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public List<Orders> getAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

}
