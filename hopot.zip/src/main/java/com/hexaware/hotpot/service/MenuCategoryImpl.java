package com.hexaware.hotpot.service;

public class MenuCategoryImpl implements IMenuCategoryService {

}
