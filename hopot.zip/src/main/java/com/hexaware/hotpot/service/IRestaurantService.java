package com.hexaware.hotpot.service;

public interface IRestaurantService {

}
