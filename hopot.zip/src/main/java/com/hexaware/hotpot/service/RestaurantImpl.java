package com.hexaware.hotpot.service;

public class RestaurantImpl implements IRestaurantService {

}
