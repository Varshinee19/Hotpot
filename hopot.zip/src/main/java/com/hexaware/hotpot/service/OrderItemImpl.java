package com.hexaware.hotpot.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hexaware.hotpot.entities.OrderItems;
@Service
public class OrderItemImpl implements IOrderItemService{

	@Override
	public OrderItems addItem(OrderItems orderItem) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<OrderItems> getItemsByOrder(int oid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderItems updateItem(OrderItems orderItem) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String removeItem(int oid) {
		// TODO Auto-generated method stub
		return null;
	}

}
