package com.hexaware.hotpot.service;

public interface ICartService {

}
