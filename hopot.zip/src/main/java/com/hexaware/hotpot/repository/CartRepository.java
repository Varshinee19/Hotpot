package com.hexaware.hotpot.repository;

public interface CartRepository {

}
